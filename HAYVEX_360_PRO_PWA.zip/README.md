# HAYVEX 360 PRO

Mobil uyumlu, Türkçe çiftlik/sürü yönetimi PWA prototipi.

## Yayınlama
Bu klasördeki dosyaları GitHub deposunun kök dizinine yükleyin. GitHub Pages ayarlarında:
- Settings → Pages
- Build and deployment → Deploy from a branch
- Branch: `main`, Folder: `/ (root)`
- Save

Yayınlanan HTTPS bağlantısını Android Chrome'da açıp menüden "Ana ekrana ekle" seçin.

## Önemli sınırlar
- Hayvan kayıtları tarayıcıdaki localStorage alanında, yalnızca bu cihaz/tarayıcıda saklanır.
- Gerçek GPS, sensör, kamera, LoRa veya veteriner teşhisi bağlantısı yoktur.
- Sağlık verileri ve cihaz durumları gerçek ölçüm değildir. Gerçek çiftlik kullanımı için güvenli sunucu/veritabanı, kimlik doğrulama, yedekleme, donanım entegrasyonu ve uzman doğrulaması gerekir.
- Bu demo gerçek hayvan sağlığı kararları için kullanılmamalıdır.
